#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>


struct datos{
	char const *archivo;
	int numeroHilo;
	int cantidadTrabajo;
	int hiloUltimo;
	int numeroTotal;
};
int primo(int numero){
	if(numero == 1 || numero == 0 ) return 0;
	for(int contador = 2; contador < numero; contador++){
		if(numero % contador == 0)
			return 0;
	}
	return 1;
} 
void trabajoHilos(struct datos *trabajo){
	struct datos datosHilo = *trabajo;
	int resultado = 0;
	int hilo = datosHilo.numeroHilo + 1; //5
	int trabajoHacer = datosHilo.cantidadTrabajo; // 6
	int inicioTrabajo, finalTrabajo;//
	FILE *archivo;
	archivo = fopen(datosHilo.archivo, "r");
	if(datosHilo.hiloUltimo)
		finalTrabajo = datosHilo.numeroTotal;
	else
		finalTrabajo = hilo * trabajoHacer; //30
	inicioTrabajo = finalTrabajo - trabajoHacer ; //0
	for (int i = 0; i < datosHilo.numeroTotal; i++){
		int numero;
		fscanf(archivo,"%d",&numero);
		if( i >= inicioTrabajo && i < finalTrabajo ){
			if(primo(numero))
				resultado++;
		}
	}
	fclose(archivo);
	pthread_exit ((void *)resultado);

}

void crearHilos(int totalHilos, char const argumento[],int numeroLineas){

	pthread_t *hilosTrabajadores;
	pthread_attr_t atributos[totalHilos];
	int valorDevuelto[totalHilos];
	hilosTrabajadores=(pthread_t *)malloc(totalHilos * sizeof(pthread_t));
	int cantidadTodos;
	int cantidadUltimo;
	struct datos trabajo[totalHilos];
	int resultado = 0;

	cantidadTodos= numeroLineas/totalHilos;
	cantidadUltimo = (numeroLineas/totalHilos) + (numeroLineas%totalHilos); 
	for (int i = 0; i < totalHilos; ++i){
		pthread_attr_init (&atributos[i]);
		pthread_attr_setdetachstate (&atributos[i], PTHREAD_CREATE_JOINABLE);
	}

	for (int i = 0; i < totalHilos; i++){
		
		trabajo[i].numeroHilo = i;
		trabajo[i].archivo = argumento;
		trabajo[i].numeroTotal = numeroLineas;
		if(i != (totalHilos-1)){
			trabajo[i].hiloUltimo = 0;
			trabajo[i].cantidadTrabajo = cantidadTodos;
			pthread_create (&(hilosTrabajadores[i]), &atributos[i], (void*)trabajoHilos, (void*)&trabajo[i]);
			
		}
		else{
			trabajo[i].cantidadTrabajo = cantidadUltimo ;//6
			trabajo[i].hiloUltimo = 1;
			pthread_create (&(hilosTrabajadores[i]), &atributos[i], (void*)trabajoHilos, (void*)&trabajo[i]);
			
		}
		
	}
	for (int i = 0; i <totalHilos; ++i){
		pthread_join(hilosTrabajadores[i],(void **)&valorDevuelto[i]);
	}
	for (int i = 0; i < totalHilos; ++i){
		resultado += valorDevuelto[i];
	}
	printf("Total de primos es %i\n", resultado);
}

int verificarCantidad(char const argumento1[], char const argumento2[]){
	if(strcmp(argumento1,"-n") == 0){
		int cantidad= 0;
		cantidad = atoi(argumento2);
		if( cantidad <= 0 || cantidad > 10){
			printf("Cantidad de numeros no permitida\n");
			exit(1);
		}else
			return cantidad;
	}else{
		printf("Parametro incorrecto\n");
		exit(1);
	}

}


int  contarLineasArchivo(char const argumento[]){
	FILE *archivo;
	int numero;
	int contador = 0;
	archivo = fopen(argumento,"r");
	if(archivo == NULL){
		fputs("El archivo no se encuentra\n",stderr);
		exit(1);
	}else{
	    while (fscanf(archivo,"%d", &numero) == 1){
	    	if(numero < 0){
	    		printf("Numero negativo encontrado\n");
	    		exit(1);
	    	}
			contador++;

	    }
	    fclose(archivo);
	    return contador;
    }
    
}

void main(int argc, char const *argv[]){
	
	int numeroLineas = contarLineasArchivo(argv[1]);
	int numeroHilos = verificarCantidad(argv[2],argv[3]);
	crearHilos(numeroHilos,argv[1],numeroLineas);

}
