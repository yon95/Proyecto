#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <wait.h>


struct datos
{
	char const *archivo;
	int numeroHilo;
	int cantidadTrabajo;
	int hiloUltimo;
	int numeroTotal;
};
void mostrarPrint (int numeroSenhal){
	printf ("I'm sorry Dave. I'm afraid I can't do that. \n");
	

	/* Se pone controlador por defecto para ctrl-c */
}
int primo(int numero){
	if(numero == 1 || numero == 0 ) return 0;
	int contador = 2;
	for(contador; contador < numero; contador++){
		if(numero % contador == 0)
			return 0;
	}
	return 1;
} 
void crearDocumento(int numero, int primo, int numeroArchivo){
	FILE *archivo;
 	char espacio = ' ';
 	char salto = '\n';
 	char extension[] = ".txt";
 	char nombre[10];
 	sprintf(nombre,"%d",numeroArchivo);
 	strcat(nombre,extension);
 	archivo = fopen(nombre,"a");

 	fprintf(archivo,"%d",numero);
 	fputc(espacio,archivo);
 	fprintf(archivo,"%d",primo);
 	fputc(salto,archivo);
 	fclose(archivo);
}

void trabajoProcesos(int numeroProceso, int trabajoHacer, char const argumento[],int ultimo,int numeroTotal){
	signal (SIGINT, SIG_IGN);
	int proceso = numeroProceso + 1; //5
	int inicioTrabajo, finalTrabajo;//
	FILE *archivo;
	archivo = fopen(argumento, "r");
	if(ultimo)
		finalTrabajo = numeroTotal;
	else
		finalTrabajo = proceso * trabajoHacer; //30
	inicioTrabajo = finalTrabajo - trabajoHacer ; //0
	for (int i = 0; i < numeroTotal; i++){
		int numero;
		fscanf(archivo,"%d",&numero);
		if( i >= inicioTrabajo && i < finalTrabajo ){
			int verificar = primo(numero);
			crearDocumento(numero,verificar,proceso);
		}
	}
	fclose(archivo);
	exit(1);

}

void crearProceso(int totalProceso, char const argumento[],int numeroLineas){
	pid_t procesos[totalProceso];
	int estadoHijos[totalProceso];
	int cantidadTodos;
	int cantidadUltimo;

	cantidadTodos= numeroLineas/totalProceso;
	cantidadUltimo = (numeroLineas/totalProceso) + (numeroLineas%totalProceso); 

	for (int i = 0; i <totalProceso; ++i)
	{
		procesos[i] = fork();

		if (!procesos[i])
			if(i== totalProceso - 1)
				trabajoProcesos(i,cantidadUltimo,argumento,1,numeroLineas);
			else
				trabajoProcesos(i,cantidadTodos,argumento,0,numeroLineas);
	}
	for (int i = 0; i < totalProceso; ++i)
	{
		waitpid(procesos[i],&estadoHijos[i],0);
	}
}

void trabajoHilos(struct datos *trabajo){
	struct datos datosHilo = *trabajo;
	int hilo = datosHilo.numeroHilo + 1; //5
	int trabajoHacer = datosHilo.cantidadTrabajo; // 6
	int inicioTrabajo, finalTrabajo;//
	FILE *archivo;
	archivo = fopen(datosHilo.archivo, "r");
	if(datosHilo.hiloUltimo)
		finalTrabajo = datosHilo.numeroTotal;
	else
		finalTrabajo = hilo * trabajoHacer; //30
	inicioTrabajo = finalTrabajo - trabajoHacer ; //0

	for (int i = 0; i < datosHilo.numeroTotal; i++){
		int numero;
		fscanf(archivo,"%d",&numero);
		if( i >= inicioTrabajo && i < finalTrabajo ){
			int verificar = primo(numero);
			crearDocumento(numero,verificar,hilo);
		}
	}
	fclose(archivo);

}

void crearHilos(int totalHilos, char const argumento[],int numeroLineas){
	
	pthread_t *hilosTrabajadores;
	hilosTrabajadores=(pthread_t *)malloc(totalHilos * sizeof(pthread_t));
	int cantidadTodos;
	int cantidadUltimo;

	cantidadTodos= numeroLineas/totalHilos;
	cantidadUltimo = (numeroLineas/totalHilos) + (numeroLineas%totalHilos); 

	struct datos trabajo[totalHilos];

	for (int i = 0; i < totalHilos; i++){
		
		trabajo[i].numeroHilo = i;//4
		trabajo[i].archivo = argumento;
		trabajo[i].numeroTotal = numeroLineas;
		if(i != (totalHilos-1)){
			trabajo[i].hiloUltimo = 0;
			trabajo[i].cantidadTrabajo = cantidadTodos;
			pthread_create (&(hilosTrabajadores[i]), NULL, (void*)trabajoHilos, (void*)&trabajo[i]);
			
		}
		else{
			trabajo[i].cantidadTrabajo = cantidadUltimo ;//6
			trabajo[i].hiloUltimo = 1;
			pthread_create (&(hilosTrabajadores[i]), NULL, (void*)trabajoHilos, (void*)&trabajo[i]);
			
		}
		
	}
	for (int i = 0; i <totalHilos; ++i){
		pthread_join(hilosTrabajadores[i],NULL);
	}
}


int verificarCantidad(char const argumento1[], char const argumento2[]){
	if(strcmp(argumento1,"-n") == 0){
		int cantidad= 0;
		cantidad = atoi(argumento2);
		if( cantidad <= 0 || cantidad > 10){
			printf("Cantidad de numeros no permitida\n");
			exit(1);
		}else
			return cantidad;
	}else{
		printf("Parametro incorrecto\n");
		exit(1);
	}

}

int verficarProcesoHilo(char const argumento[]){

	if(strcmp(argumento,"-t") == 0 )
		return 1;
	else if(strcmp(argumento,"-p") == 0)
		return 0;
	else{
		printf("ingreso un parametro que no corresponde ni a hilo ni proceso\n");
		exit(1);
	}
}


int  contarLineasArchivo(char const argumento[]){
	FILE *archivo;
	int numero;
	int contador = 0;
	archivo = fopen(argumento,"r");
	if(archivo == NULL){
		fputs("El archivo no se encuentra\n",stderr);
		exit(1);
	}else{
	    while (fscanf(archivo,"%d", &numero) == 1){
	    	if(numero < 0){
	    		printf("Numero negativo encontrado\n");
	    		exit(1);
	    	}
			contador++;

	    }
	    fclose(archivo);
	    return contador;
    }
    
}

void main(int argc, char const *argv[]){
	signal (SIGINT, mostrarPrint);
	int numeroLineas = contarLineasArchivo(argv[1]);
	if (verficarProcesoHilo(argv[2]) == 1){
		int numeroHilos = verificarCantidad(argv[3],argv[4]);
		crearHilos(numeroHilos,argv[1],numeroLineas);
	}else{
		int numeroProcesos = verificarCantidad(argv[3],argv[4]); 
		crearProceso(numeroProcesos,argv[1],numeroLineas);
	}
}
