	#include <stdio.h>
	#include <stdlib.h>
	#include <stdint.h>
	#include <string.h>
	#include <wait.h>
	#include <unistd.h>
	#include <sys/shm.h>
	#include <sys/types.h>
	#include <sys/ipc.h>
	#include <sys/sem.h>
	#include <sys/mman.h>
	#include <semaphore.h>

struct lista{

	int numero;
	char sendero;
	struct lista *sig;

};
	/* 
	*la lista es global
	*/
struct lista *contenedor = NULL;
int total = 0;

void insertar(char *numero,char senderoC){

	struct lista *caja = (struct lista *)malloc(sizeof(struct lista));
	struct lista *tmp;
	caja->numero = atoi(numero);
	caja->sendero = senderoC;
	caja->sig = NULL;
	if(contenedor == NULL){
		caja->sig = contenedor;
		contenedor = caja;
	}else{
		tmp = contenedor;
		while(tmp->sig != NULL) tmp = tmp->sig;
		tmp->sig = caja;
	}

}
// void mostrarStruct(){
// 	struct lista *tmp;
// 	tmp = contenedor;
// 	printf("entrada ->");
// 	while(tmp != NULL){
// 		printf("[%i %c]->",tmp->numero,tmp->sendero);
// 		tmp = tmp->sig;
// 	}
// 	printf("NULL\n");
// }
void llenarStruct(){

	FILE *archivo;
	archivo = fopen("entrada.txt","r");
	char linea[5];
	char numero[3];
	char sendero;
	if (archivo == NULL){
		printf("error archivo");
		exit(1);
	}else{
		while(!feof(archivo)){

			fgets(linea, 6,archivo);
			total++;
			int i = 0;
			// if(feof(archivo) != 0)
			// 	break
			while(linea[i] != ' ' ){
				numero[i] = linea[i];
				i++;
			}
			i++;
			sendero = linea[i];
			insertar(numero,sendero);
		}
	}	
}

void ordenarStruct(){
		/*
		*Puntero principal para recorrer la lista
		*Puntero movimiento para ir buscando el menor
		*Puntero menor para que se mantenga en el menor valor
		*/
	struct lista *principal;
	struct lista *menor;
	struct lista *movimiento ;
	int cambio = 0;
	char dato;
	int valor = 0;
	menor = contenedor;
	principal = contenedor;
	while(principal!= NULL){
		valor = principal->numero;
		if(principal->sig != NULL){
			movimiento= principal->sig;
			while(movimiento!= NULL){
				if (valor >  movimiento->numero){
					menor = movimiento;
					valor = movimiento->numero;
					cambio = 1;
				}
				movimiento= movimiento->sig;
			}
			if(cambio){
				valor = principal->numero;
				principal->numero = menor->numero;
				menor->numero = valor;
				dato = principal->sendero;
				principal->sendero = menor->sendero;
				menor->sendero = dato;
				cambio = 0;
			}

		}
		principal = principal->sig;
	}
}

void crearDocumento(int numero, char sendero, int verificar){
	FILE *archivo;
 	char espacio = ' ';
 	char salto = '\n';
 	archivo = fopen("salida.txt","a");
 	if(verificar){
 		char cadena[] = "Esperando...\n";
 		fwrite(cadena,sizeof(char),sizeof(cadena),archivo);
 	}else{
	 	fprintf(archivo,"%d",numero);
	 	fputc(espacio,archivo);
	 	fputc(sendero,archivo);
	 	fputc(salto,archivo);
 	}
 	fclose(archivo);
}
void eliminarAmbos(){
    pid_t izquierda;
    sem_t *semaforoL = mmap(NULL, sizeof(sem_t), PROT_READ | PROT_WRITE,
             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sem_t *semaforoR = mmap(NULL, sizeof(sem_t), PROT_READ | PROT_WRITE,
             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    int *pendiente = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE,
             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    int *contador = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE,
             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    int *tiempoL = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE,
             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    int *listo = mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE,
             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    *contador = 1;
    *tiempoL = 1;
    *pendiente = 0;
    *listo = 0;
    sem_init (semaforoL, 1, 1);
    sem_init (semaforoR, 1, 1);
    izquierda = fork();

    if(!izquierda){
        
        struct lista *movedor;
        if( *contador == 1 && contenedor->sendero == 'R') {
			sem_wait(semaforoL);
        }
        while(1){
        	sem_wait(semaforoL);
            movedor = contenedor;
            int adentro = 1;
            int comprobar = 1;
            int validar = 0;
            while(*tiempoL != movedor->numero){
                if(movedor->sig != NULL){
                    movedor = movedor->sig;
                }else {
                   // printf("Terminó L\n");
                    adentro = 0;
                    if(*listo != 10) *listo = 5;
                    break;
                }
            }
            if(!adentro) break;

            while(movedor->numero == *tiempoL){
            	if(comprobar == 1 && *pendiente) *pendiente = 0;
            	if(movedor->sendero =='L'){
            		crearDocumento(*contador,movedor->sendero,0);
            	//	printf("Soy el L y elimine el %i %c contador %i\n", movedor->numero,movedor->sendero, *contador);
            		*contador = *contador + 1;
            	}else{
            		if(!*listo) *pendiente = 1;
            	}
            	if(movedor->sig != NULL){
            		movedor = movedor->sig;
            		comprobar++;
            	}else break;
            }
            *listo = 1;

            if(!*pendiente){
            	*tiempoL = *tiempoL + 1;
            	*listo = 0;
            	while(movedor->numero == *tiempoL){
            		
	            	if( movedor->sendero == 'L'){
	            		validar = 1; //aaa
	            		break;
	            	}
	            	if(movedor->sig != NULL)
            			movedor = movedor->sig;
            		else break;
            	}

            }
            if(validar == 1 )
            	sem_post(semaforoL);
            else
            	sem_post(semaforoR);
    	}
    	if(*listo == 5) sem_post(semaforoR);
        
    }else if(izquierda > 0){
        
        struct lista *movedor;
        if( *contador == 1 && contenedor->sendero == 'L') {
			sem_wait(semaforoR);
        }
        while(1){
        	sem_wait(semaforoR);
            movedor = contenedor;
            int adentro = 1;
            int comprobar = 1;
            int validar = 0;
            while(*tiempoL != movedor->numero){

                if(movedor->sig != NULL){
                    movedor = movedor->sig;
                }else {
                   // printf("Terminó R\n");
                    if(*listo != 5) *listo = 10;
                    adentro = 0;
                    break;
                }
            }
            if(!adentro) break;

            while(movedor->numero == *tiempoL){

            	if(comprobar == 1 && *pendiente) *pendiente = 0;
            	if(movedor->sendero =='R'){
            		crearDocumento(*contador,movedor->sendero,0);
            		//printf("Soy el R y elimine el %i %c contador %i\n", movedor->numero,movedor->sendero, *contador);
            		*contador = *contador + 1;
            	}else{
            		if(!*listo) *pendiente = 1;
            	}
            	if(movedor->sig != NULL){
            		movedor = movedor->sig;
            		comprobar++;
            	}else break;
            }
            *listo = 1;
            
            if(!*pendiente){
            	*tiempoL = *tiempoL + 1;
            	*listo = 0;
            	while(movedor->numero == *tiempoL){
            		
	            	if( movedor->sendero == 'R'){
	            		validar = 1; //aaa
	            		break;
	            	}
	            	if(movedor->sig != NULL)
            			movedor = movedor->sig;
            		else break;
            	}

            }
            if(validar == 1 )
            	sem_post(semaforoR);
            else
            	sem_post(semaforoL);
        }
        if(*listo== 10) sem_post(semaforoL);
    }
    wait(NULL);
    munmap(contador, sizeof(int));
    munmap(semaforoR, sizeof(sem_t));
    munmap(semaforoL, sizeof(sem_t));
    munmap(tiempoL, sizeof(int));
    munmap(pendiente, sizeof(int));
    munmap(listo, sizeof(int));



}
void main(){
	llenarStruct();
	ordenarStruct();
	printf("%i\n",total );
	eliminarAmbos();
}
